import sys, pygame
import stats, movement, classSelection

playerClass=classSelection.classSelection()
if playerClass==0:
	playerStat=[100,100,'Sword','A5',10,10,5,1]
	playerClass='Knight'